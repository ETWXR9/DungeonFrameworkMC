package me.etwxr9.roguelike.Game;

import org.bukkit.entity.Item;
import org.bukkit.inventory.ItemFactory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ItemData {
    public ItemStack itemStack;
    public String Id;

}

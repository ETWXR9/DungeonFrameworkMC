package me.etwxr9.roguelike.Game;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static java.util.Map.entry;

import java.util.ArrayList;

import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.lib.jse.CoerceJavaToLua;

import me.etwxr9.roguelike.Main;

public class LuaListenerManager implements Listener {
    // Hashmap<事件名,<道具Id>>
    public static Map<String, List<String>> luaFuncMap = Map.ofEntries(
            entry("onEntityDamageByEntity", new ArrayList<String>()), entry("onSpawnEnemy", new ArrayList<String>()));

    // public static LuaValue GetItem(Player p, String itemId) {
    // DungeonTour tour = TourManager.GetTour(p);
    // if (tour == null) {
    // return null;
    // }
    // if (tour.ItemList.containsKey(itemId)) {
    // p.sendMessage("检查当前具备道具 " + itemId);
    // return tour.ItemList.get(itemId);
    // }
    // p.sendMessage("检查当前不具备道具 " + itemId);
    // return null;
    // }

    @EventHandler
    public void onEntityDamagedByEntity(EntityDamageByEntityEvent e) {
        Main.getInstance().getServer().broadcastMessage("发生EntityDamageByEntity事件，实体为 " + e.getDamager().getType());
        if (e.getDamager().getType() == EntityType.PLAYER) {
            var p = (Player) e.getDamager();
            var tour = TourManager.GetTour(p);
            if (tour == null) {
                return;
            }
            luaFuncMap.get("onEntityDamageByEntity").forEach((itemName) -> {
                LuaValue itemLua = tour.ItemLuaList.get(itemName);
                itemLua.get("onEntityDamageByEntity").call(itemLua, CoerceJavaToLua.coerce(e));
                p.sendMessage("执行道具逻辑 " + itemName);
            });

        }

    }
}
